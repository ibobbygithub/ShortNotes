<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
	<title></title>
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-md-12"></div>
			<form id="#frm" method="get" action="formshow.php">
				<table class="table table-bordered">
				<tr>
				</tr>
				<tr>
					<td class="text-center">Input</td>
					<td><input id="fullname" type="text" name="myname" class="form-control"></td>
				</tr><tr>
					<td class="text-center">password</td>
					<td><input id="pwd" type="password" name="mypassword" class="form-control">
						<input type="button" id="view" name="view" value="show pass" class="btn btn-success"></td>

				</tr>
				<tr>
					<td class="text-center">Drop down></td>
					<td>
						<select name="year" class="form-control" 
						style="display: inline; width: 100px;">
							<?php 
								$thisDay = date('j');
								$thisMonth = date('n');
								$thisYear = date('Y');
							?>
							<option value="">--select year--</option>
							<?
								for($y=date('Y');$y>date('Y')-100;$y--){
							?>
							<option value="<?=$y ?>" <? if($y==$thisYear){echo "selected";} ?>><?=$y?></option>
							<? } ?>
						</select> /
						<select name="day" class="form-control"
						style="display: inline; width: 100px;">
							<option value="" >--select day--</option>
							
							<?
								for($d=1;$d<=31;$d++){
							?>
							<option value="<?=$d ?>" <? if($d==$thisDay){echo "selected";} ?>><?=$d?></option>
							<? } ?>
						</select> /
						<?php 
							$months = array(
						    'January',
						    'February',
						    'March',
						    'April',
						    'May',
						    'June',
						    'July ',
						    'August',
						    'September',
						    'October',
						    'November',
						    'December',
						);
						?>
						<select name="month" class="form-control"
						style="display: inline; width: 100px;">
							<option value="">--select month--</option>
							<?
								for($m=0;$m<12;$m++){
							?>
							<option value="<?=$m ?>" 
								<? if($m+1==$thisMonth){echo "selected";} ?>
							>
								<?=$months[$m]?></option>
							<? } ?>
						</select> 
					</td>
				</tr>
				<tr>
					<td class="text-center">Checkbox</td>
					<td>
						<input name="chk[]" type="Checkbox" value="1" checked=""> Choice1 <br>
						<input name="chk[]" type="Checkbox" value="2" checked=""> Choice2 <br>
						<input name="chk[]" type="Checkbox" value="3" checked=""> Choice3 <br>
					</td>
				</tr>
				<tr>
					<td class="text-center">Input Radio</td>
					<td>
						<input name="gender" type="radio"> Male <br>
						<input name="gender" type="radio"> Female <br>
					</td>
				</tr>
				<tr>
					<td class="text-center">Input Area</td>
					<td>
						<textarea name="comment" class="form-control" rows="5">
							
						</textarea>
					</td>
				</tr>
				<tr>
					<td class="text-center">Input Button</td>
					<td>
						<input type="submit" name="submit" class="btn btn-success" value="Send data">
						<input id="btnx" type="button" class="btn btn-warning" value="Send data">
						<input type="reset" class="btn btn-danger" value="Send data">
					</td>
				</tr>
			</table>
			</form>
			
		</div>
	</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script type="text/javascript">
	//Tag selector
	//$("div").length;
	//Class selector
	//$(".form-control").length;
	//id selector
	//$("#frm").hide();
	//$("#frm").hide();
	//$('#fullname').css('border','1px solid red');
	$('#view').click(function(){
		if($('#pwd').attr('type')=='password'){
			$('#pwd').attr('type','input');
		} else {
			$('#pwd').attr('type','password');
		}
	});

	$('#btnx').click(function(){
		//JSON
		//alert('fuck yeah');
		var a = $('#fullname').val();
		var b = $('#password').val();
		var params = {"a":a,"b":b}
		$.post('responeAJAX.php',params,function(data){
			alert(data);
		});
	});

</script>
</body>
</html>