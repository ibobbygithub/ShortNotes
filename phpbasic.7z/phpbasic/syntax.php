<?php 
	echo "hello world<br>";
	echo 'hello world<br>';

	$x = 10;
	$y = 10.5;
	$z = "Bobby";

	echo "$x $y $z<br>";
	echo '$x $y $z';

	#operation
	echo "$x + $y = " . ($x+$y) ."<br>";

	#condition
	$bol = tRuE;
	if($bol)
		echo "<br>very good<br>";

	#if-else statement
	if($x < $y){
		echo "<br>very well!";
		echo "<br>very cleaver<br>";
	}
	#loop
	for ($i=20;$i>0;$i--){
		if($i%2==0)
			echo "<br>$i";
	}

	#array
	$cars = array("volvo","BWM","Toyota");
	for ($i=0;$i<sizeof($cars);$i++){
		echo "<br>" . $cars[$i] ;
	}
	echo "<br>";
	#for each run until the last value on index
	$color = array('red' => '#FF0000','green' => '#00FF00', 'blue' => '#FF0000');
	foreach ($color as $key => $value) {
		echo "<br><i style='color:$value'>
				$key = $value
			</i><br>";
	}
 ?>