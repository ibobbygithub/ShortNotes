<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
	<title></title>
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-md-12"></div>
				<table class="table table-bordered">
				<tr>
					<td>Name</td>
					<td>Form Input</td>
				</tr>
				<tr>
					<td class="text-center">Input</td>
					<td><?php echo $_GET['myname']; ?></td>
				</tr><tr>
					<td class="text-center">password</td>
					<td><?php echo $_GET['mypassword']; ?></td>
				</tr>
				<tr>
					<td class="text-center">Checkbox</td>
					<td>
					<?php
					 print_r($_GET['chk']); 
					 foreach ($_GET['chk'] as $key => $value) {
					 	echo "$key = $value<br>";
					}
					?>
						
					</td>
				</tr>
				<tr>
					<td class="text-center">Input Radio</td>
					<td><?php echo $_GET['gender']; ?>
					</td>
				</tr>
				<tr>
					<td class="text-center">Input Area</td>
					<td><?php echo $_GET['comment']; ?>
					</td>
				</tr>
				<tr>
					<td class="text-center">Input Button</td>
					<?php echo $_GET['submit']; ?>
					<td>
					</td>
				</tr>
			</table>
		</div>
	</div>
	
</body>
</html>